<?php
$judul = array(
    "Classic",
    "Models",
    "Database"
);
?>